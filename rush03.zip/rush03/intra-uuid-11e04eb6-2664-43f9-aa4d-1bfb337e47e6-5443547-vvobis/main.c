/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vvobis <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/27 12:39:16 by vvobis            #+#    #+#             */
/*   Updated: 2024/01/28 21:05:39 by vvobis           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush.h"

int r_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	while (s1[i] == s2[i] && s2[i])
		i++;
	return (s1[i] - s2[i]);
}

char *r_itoa(int nb)
{
	char *str;

	str = (char *)malloc(sizeof(*str) * 3);
		str[0] = nb;
		str[1] = '0';
	str[2] = 0;
	return (str);
}

char **conver_ints(int *n)
{
	char **res;

	res = malloc(sizeof(*res) * 4);
	n[0] -= 48;
	n[1] -= 48;
	n[2] -= 48;
	res[0] = r_itoa(n[0]);
	res[1] = r_itoa(100);
	if(n[1] < 2)
	{
		n[1] = (n[1] * 10) + n[2];
		res[2] = r_itoa(n[1]);
		return (res);
	}
	else 
	{
		res[3] = r_itoa(n[1] * 10);
		res[4] = r_itoa(n[2]);
	}
	return (res);
}

int r_find_line(t_dict *dict, char *str)
{
	int i;
	
	i = 0;
	while (i < dict->entry_count)
	{
		if(!r_strcmp(str, dict->entries[i]->data_desc))
		{
			r_putstr(dict->entries[i]->data);
			return (1);
		}
		i++;
	}
	return (0);
}

int main()
{
	t_dict *dict = r_dict_create();
	char *input = "1234567";	
	char **input_parsed = r_parsed_input_create(input);
	int comp = r_combined_strlen((int **)input_parsed);
	int i;
	r_read_line_parsed(dict);
	printf("comp: %d\n", comp);

	i = 0;
	while (i < comp)
	{
		r_find_line(dict, &*input_parsed[i]);
		i++;
	}
	
	//r_parsed_input_free((int **)input_parsed);
	r_dict_destroy(dict);
}
